/*
#include <at89x52.h>//contem as defini�oes do chip

void espera(int time_ms){
	int j;
	for(j=0;j<time_ms;j++){
		int a=1275;
		while(a > 0)
			a = a - 1;
	}
	
}

void atendeInterrupt(){
	//TR0=0;//ause timer para recarregar 
	//TH0=0x3C;//recarrega o timer com o valor inicial de
//	TL0=0xAF;//15.535
//	TR0=1;
	
	//P3_0 = 0;
	
	if(P3_1 == 1){ //botao do cafe
		espera(1000);
		P2_1 = 1; //pino para representar a saida do cafe
		P0 = 0;
		espera(1000);
		P3=0;
	}else if(P3_2 == 1){ //botao do cha
		espera(1000);
		P0_1 = 1;//pino para representar a saida do cha
		P2 = 0;
		espera(1000);
		P3=0;
	}
	
	//P3 = 0;
	//P2 = 0; 
	//P0 = 0;
	
}
	
void main(){
//	EA=1;//habilita chave geral das interrup�oes
//	ET0=1;///habilita a interrup��o por estouro de Timer0
	//TMOD=1;//habilita Timer0 no modo 16bits
	//TR0=1;//Ativa Timer0 no modo 16 bits
	
	
	P3 = 0;
	P2 = 0;
	P0 = 0; 
	
	 //coin inserido
		while(1){
			if(P3_0 == 1){ //pino para inserir a moeda
				atendeInterrupt();
				espera(1000);
				P0 = 0;
				P2 = 0;
			}			
			
		}
		
	
}
*/