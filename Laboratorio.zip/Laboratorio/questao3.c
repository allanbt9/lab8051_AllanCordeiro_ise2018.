/*
#include <at89x52.h>//contem as defini�oes do chip

int cont=0;
int cameraDaVez=0;

void espera(int time_ms){
	int j;
	for(j=0;j<time_ms;j++){
		int a=1275;
		while(a > 0)
			a = a - 1;
	}
}

void camera(){
	if(cameraDaVez == 0){
			P0_0 = 1;
			espera(9000);
	}else if(cameraDaVez == 1){
			P0_0 = 0;
			P0_1 = 1;
			espera(9000);
	}else if(cameraDaVez == 2){
			P0_1 = 0;
			P0_2 = 1;
			espera(9000);
	}else if(cameraDaVez == 3){
			P0_2 = 0;
			P0_3 = 1;
			espera(9000);
			P0_3 = 0;
	}
	
}


void atendeTimer() interrupt 1{
	TR0=0; //pausa timer para recarregar (Timer Stop)
	TH0=0x3C; //recarrega o timer com o valor inicial de
	TL0=0xAF; //15.535
	TR0=1; //ativa timer para contar (Timer RUN)
	

	
	if(P1_0 || P1_1 || P1_2 || P1_3){
		camera();
		cameraDaVez++;
	}
	if(cameraDaVez > 3)
			cameraDaVez = 0;
	
}
void main(){
	EA=1; //habilita chave geral das interrup��es
	ET0=1; //habilita a interrup��o por estouro de Timer0
	TMOD=1; //habilita Timer0 no modo 16 bits
	TR0=1; //Ativa Timer0 no modo �roda�

	
	P0 = 0;// pino das cameras
	P1 = 0; //pino dos sensores de presen�a
	while(1){
	
	}
	
}

*/