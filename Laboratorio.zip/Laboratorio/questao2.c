/*
#include <at89x52.h>//contem as defini�oes do chip
//#include <stdio.h>

int cont=0;
int verifica=0;

void espera(int time_ms){
	int j;
	for(j=0;j<time_ms;j++){
		int a=1275;
		while(a > 0)
			a = a - 1;
	}
}
	
void newBox(){
	if(verifica == 0){
		P0_0 = 1;
	}else if(verifica == 1){
		espera(1000);
		P1 = 0;
		P0_1 = 1;
		P0_0 = 0;
	}else if(verifica == 2){
		espera(1000);
		P1 = 0;
		P0_2 = 1;
		P0_1 = 0;
	//	cont=0;
	}else if(verifica == 3){
		espera(1000);
		P1 = 0;
		P0_3 = 1;
		P0_2 = 0;
	//	cont=0;
	}else if(verifica == 4){
		espera(1000);
		P1 = 0;
		P0_4 = 1;
		P0_3 = 0;
	//	cont=0;
	}else if(verifica == 5){
		espera(1000);
		P1 = 0;
		P0_5 = 1;
		P0_4 = 0;
	//	cont=0;
	}else if(verifica == 6){
		espera(1000);
		P1 = 0;
		P0_6 = 1;
		P0_5 = 0;
	//	cont=0;
	}else if(verifica == 7){
		espera(1000);
		P1 = 0;
		P0_7 = 1;
		P0_6 = 0;
		//verifica = 0;
		//cont = 0;
	}
	
	
}

void atendInterrupt() interrupt 1{
	
	TR0=0;//pausa timer para recarregar 
	TH0=0x3C;//recarrega o timer com o valor inicial de
	TL0=0xAF;//15.535
	TR0=1;
	

	cont++;
	//printf("cont: %d\n",cont);
	if(cont ==  20){
		espera(1000);
		P1_0 = 1;
	}
	else if(cont ==  40){
		espera(1000);
		P1_1 = 1;
	}else if(cont ==  80){
		espera(1000);
		P1_2 = 1;
	}else if(cont ==  120){
		espera(1000);
		P1_3 = 1;
	}else if(cont ==  160){
		espera(1000);
		P1_4 = 1;
	}else if(cont ==  200){
		espera(1000);
		P1_5 = 1;
	}else if(cont ==  240){
		espera(1000);
		P1_6 = 1;
	}else if(cont ==  280){
		espera(1000);
		P1_7 = 1;
		verifica++;
		newBox();
		cont=0;
	}

}

void main(){
	EA=1;//habilita chave geral das interrup�oes
	ET0=1;///habilita a interrup��o por estouro de Timer0
	TMOD=1;//habilita Timer0 no modo 16bits
	TR0=1;//Ativa Timer0 no modo 16 bits
	
	P0 = 0; //pino das caixas
	P1 = 0; //pino dos produtos
	newBox();
	
	while(1){
		
	} 
}

*/
